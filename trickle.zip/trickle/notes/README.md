# FitAI - Healthcare Assistant Platform

FitAI is a modern healthcare assistant platform where users can share advice, read community posts, and access an AI assistant (Premium feature).

## Features
- **User System**: Register, Login, Email confirmation (simulated), Profile management.
- **Advice Feed**: Community-driven advice posts (create, read, like, comment).
- **Premium Membership**: Unlock AI Assistant access using Admin-generated Redeem Codes.
- **Admin Panel**: Dashboard for admins to generate and view redeem codes.
- **Admin Access**: Backdoor login via login page or Settings page using special key.

## Pages
- `/index.html`: Landing page.
- `/login.html`: User login.
- `/register.html`: User registration.
- `/feed.html`: Community advice feed (Posts & Likes).
- `/settings.html`: User settings (Profile, Theme, Redeem Premium, Admin Access).
- `/admin.html`: Admin dashboard (Redeem Code Management).

## Tech Stack
- Frontend: React 18, TailwindCSS
- Backend: Trickle Database (Serverless)
- Icons: Lucide Static