When updating the project
- Always check if the changes require an update to `trickle/notes/README.md`.
- Ensure the README accurately reflects the current project structure, features, and setup instructions.