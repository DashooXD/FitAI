/**
 * Utilities for interacting with Trickle Database
 */

// Helper to handle API errors
const handleDbError = (error, context) => {
    console.error(`DB Error in ${context}:`, error);
    throw error;
};

// USER OPERATIONS
window.dbCreateUser = async (userData) => {
    try {
        // Check if email already exists
        const existingUsers = await window.dbListUsers(); // simplistic check for prototype
        if (existingUsers.find(u => u.objectData.email === userData.email)) {
            throw new Error('Email already registered');
        }
        if (existingUsers.find(u => u.objectData.username === userData.username)) {
            throw new Error('Username already taken');
        }

        return await trickleCreateObject('user', {
            ...userData,
            isPremium: false,
            role: 'user', // default role
            joinDate: new Date().toISOString()
        });
    } catch (error) {
        handleDbError(error, 'createUser');
    }
};

window.dbLoginUser = async (email, password) => {
    try {
        const result = await trickleListObjects('user', 100, true);
        const user = result.items.find(u => u.objectData.email === email && u.objectData.password === password);
        return user;
    } catch (error) {
        handleDbError(error, 'loginUser');
    }
};

// Admin backdoor helper: Find user by email without password check
window.dbFindUserByEmail = async (email) => {
    try {
        const result = await trickleListObjects('user', 100, true);
        return result.items.find(u => u.objectData.email === email);
    } catch (error) {
        handleDbError(error, 'findUserByEmail');
    }
};

window.dbUpdateUserPremium = async (userId, isPremium) => {
    try {
        return await trickleUpdateObject('user', userId, { isPremium });
    } catch (error) {
        handleDbError(error, 'updateUserPremium');
    }
};

window.dbUpdateUserProfile = async (userId, profileData) => {
    try {
        return await trickleUpdateObject('user', userId, profileData);
    } catch (error) {
        handleDbError(error, 'updateUserProfile');
    }
};

window.dbUpdateUserRole = async (userId, role) => {
    try {
        return await trickleUpdateObject('user', userId, { role });
    } catch (error) {
        handleDbError(error, 'updateUserRole');
    }
};

window.dbListUsers = async () => {
    try {
        const result = await trickleListObjects('user', 1000, true);
        return result.items;
    } catch (error) {
        handleDbError(error, 'listUsers');
        return [];
    }
};

window.dbGetUser = async (userId) => {
    try {
        return await trickleGetObject('user', userId);
    } catch (error) {
        handleDbError(error, 'getUser');
    }
}


// POST OPERATIONS
window.dbCreatePost = async (postData) => {
    try {
        return await trickleCreateObject('post', {
            ...postData,
            likedBy: [],
            createdAt: new Date().toISOString()
        });
    } catch (error) {
        handleDbError(error, 'createPost');
    }
};

window.dbListPosts = async () => {
    try {
        const result = await trickleListObjects('post', 100, true);
        return result.items;
    } catch (error) {
        handleDbError(error, 'listPosts');
        return [];
    }
};

window.dbUpdatePostLikes = async (postId, likedBy) => {
    try {
        return await trickleUpdateObject('post', postId, { likedBy });
    } catch (error) {
        handleDbError(error, 'updatePostLikes');
    }
}

window.dbDeletePost = async (postId) => {
    try {
        return await trickleDeleteObject('post', postId);
    } catch (error) {
        handleDbError(error, 'deletePost');
    }
}

// COMMENT OPERATIONS
window.dbCreateComment = async (commentData) => {
    try {
        return await trickleCreateObject('comment', {
            ...commentData,
            createdAt: new Date().toISOString()
        });
    } catch (error) {
        handleDbError(error, 'createComment');
    }
};

window.dbListComments = async (postId) => {
    try {
        // Client side filtering for prototype
        const result = await trickleListObjects('comment', 1000, true);
        return result.items.filter(item => item.objectData.postId === postId);
    } catch (error) {
        handleDbError(error, 'listComments');
        return [];
    }
};

// REDEEM CODE OPERATIONS
window.dbCreateRedeemCode = async (code) => {
    try {
        return await trickleCreateObject('redeem_code', {
            code,
            isUsed: false,
            createdAt: new Date().toISOString()
        });
    } catch (error) {
        handleDbError(error, 'createRedeemCode');
    }
};

window.dbListRedeemCodes = async () => {
    try {
        const result = await trickleListObjects('redeem_code', 100, true);
        return result.items;
    } catch (error) {
        handleDbError(error, 'listRedeemCodes');
        return [];
    }
};

window.dbUseRedeemCode = async (codeStr) => {
    try {
        const codes = await window.dbListRedeemCodes();
        const target = codes.find(c => c.objectData.code === codeStr && !c.objectData.isUsed);
        
        if (!target) return null;

        await trickleUpdateObject('redeem_code', target.objectId, { isUsed: true });
        return target;
    } catch (error) {
        handleDbError(error, 'useRedeemCode');
    }
};