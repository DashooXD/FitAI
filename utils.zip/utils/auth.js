/**
 * Simple Authentication Management using localStorage
 */

const STORAGE_KEY = 'fitai_user_session';
const THEME_KEY = 'fitai_theme';

window.authLogin = (userObject) => {
    const userData = {
        id: userObject.objectId,
        ...userObject.objectData
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userData));
    window.dispatchEvent(new Event('auth-change'));
};

window.authLogout = () => {
    localStorage.removeItem(STORAGE_KEY);
    window.dispatchEvent(new Event('auth-change'));
    window.location.href = 'login.html';
};

window.getCurrentUser = () => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : null;
    } catch (e) {
        return null;
    }
};

window.updateUserSession = (updates) => {
    const user = window.getCurrentUser();
    if (user) {
        const updated = { ...user, ...updates };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        window.dispatchEvent(new Event('auth-change'));
    }
}

// Theme handling
window.getTheme = () => localStorage.getItem(THEME_KEY) || 'light';
window.setTheme = (theme) => {
    localStorage.setItem(THEME_KEY, theme);
    document.documentElement.classList.toggle('dark', theme === 'dark');
    window.dispatchEvent(new Event('theme-change'));
};

// Initialize theme on load
const initTheme = () => {
    const theme = window.getTheme();
    if (theme === 'dark') {
        document.documentElement.classList.add('dark');
    }
};
initTheme();